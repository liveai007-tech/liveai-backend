# 🚀 LiveAi NestJS Backend API — 100% Free Edition

LiveAi is an AI companion application powered by NestJS and Supabase PostgreSQL. This backend is **completely FREE forever** — no paywalls, no subscriptions, no Razorpay or Google Play Billing code. All registered users are granted `lifetime_active` status automatically.

---

## 🛠️ Local Development

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run start:dev
